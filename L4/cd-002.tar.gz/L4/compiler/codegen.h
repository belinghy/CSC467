#ifndef _CODEGEN
#define _CODEGEN 1

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "common.h"
#include "ast.h"

void genCode(node *ast);

#endif