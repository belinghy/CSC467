/* A Bison parser, made by GNU Bison 3.0.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2013 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    INTLIT = 258,
    FLOATLIT = 259,
    BOOLEANLIT = 260,
    ID = 261,
    ASSIGN = 262,
    GT = 263,
    LT = 264,
    NOT = 265,
    XOR = 266,
    MUL = 267,
    DIV = 268,
    ADD = 269,
    SUB = 270,
    EQ = 271,
    NE = 272,
    LE = 273,
    GE = 274,
    AND = 275,
    OR = 276,
    SEMICOLON = 277,
    COMMA = 278,
    DOT = 279,
    OPEN_BRACKET = 280,
    CLOSE_BRACKET = 281,
    OPEN_BRACES = 282,
    CLOSE_BRACES = 283,
    OPEN_SQ_BRACKET = 284,
    CLOSE_SQ_BRACKET = 285,
    TYPE_INT = 286,
    TYPE_BOOL = 287,
    TYPE_FLOAT = 288,
    TYPE_VEC2 = 289,
    TYPE_VEC3 = 290,
    TYPE_VEC4 = 291,
    TYPE_BVEC2 = 292,
    TYPE_BVEC3 = 293,
    TYPE_BVEC4 = 294,
    TYPE_IVEC2 = 295,
    TYPE_IVEC3 = 296,
    TYPE_IVEC4 = 297,
    FUNC_DP3 = 298,
    FUNC_LIT = 299,
    FUNC_RSQ = 300,
    VOID = 301,
    CONST = 302,
    WHILE = 303,
    IF = 304,
    ELSE = 305
  };
#endif
/* Tokens.  */
#define INTLIT 258
#define FLOATLIT 259
#define BOOLEANLIT 260
#define ID 261
#define ASSIGN 262
#define GT 263
#define LT 264
#define NOT 265
#define XOR 266
#define MUL 267
#define DIV 268
#define ADD 269
#define SUB 270
#define EQ 271
#define NE 272
#define LE 273
#define GE 274
#define AND 275
#define OR 276
#define SEMICOLON 277
#define COMMA 278
#define DOT 279
#define OPEN_BRACKET 280
#define CLOSE_BRACKET 281
#define OPEN_BRACES 282
#define CLOSE_BRACES 283
#define OPEN_SQ_BRACKET 284
#define CLOSE_SQ_BRACKET 285
#define TYPE_INT 286
#define TYPE_BOOL 287
#define TYPE_FLOAT 288
#define TYPE_VEC2 289
#define TYPE_VEC3 290
#define TYPE_VEC4 291
#define TYPE_BVEC2 292
#define TYPE_BVEC3 293
#define TYPE_BVEC4 294
#define TYPE_IVEC2 295
#define TYPE_IVEC3 296
#define TYPE_IVEC4 297
#define FUNC_DP3 298
#define FUNC_LIT 299
#define FUNC_RSQ 300
#define VOID 301
#define CONST 302
#define WHILE 303
#define IF 304
#define ELSE 305

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE YYSTYPE;
union YYSTYPE
{
#line 57 "parser.y" /* yacc.c:1909  */

  int     num;
  int     ival;
  float   fval;
  bool    bval;
  char    *str;
  char    cval;

#line 163 "y.tab.h" /* yacc.c:1909  */
};
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
